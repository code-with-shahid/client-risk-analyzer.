# 🌤️ AI Weather Forecast App with Clothing Suggestions 👕

A weather app built with React that provides live weather data and AI-based clothing suggestions.

## 🚀 How to Run

```bash
npm install
npm start
```

## 🔑 Replace your OpenWeatherMap API key
In `src/components/WeatherApp.jsx`, replace `"YOUR_OPENWEATHERMAP_API_KEY"` with your actual key.

## 📦 Tech Used

- React
- OpenWeatherMap API
