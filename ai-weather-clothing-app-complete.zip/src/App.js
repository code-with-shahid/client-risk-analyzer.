import WeatherApp from './components/WeatherApp';

function App() {
  return <WeatherApp />;
}

export default App;
