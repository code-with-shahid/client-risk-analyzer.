import React, { useState } from 'react';

const API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"; // Replace with your actual API key

const getClothingSuggestion = (temp, weather) => {
  if (weather.includes("rain")) return "Carry an umbrella or wear a raincoat.";
  if (temp < 10) return "Wear a warm coat, scarf, and gloves.";
  if (temp >= 10 && temp < 20) return "Wear a jacket or sweater.";
  if (temp >= 20 && temp < 30) return "A t-shirt and jeans should be fine.";
  return "Light clothes are best. Stay hydrated!";
};

export default function WeatherApp() {
  const [city, setCity] = useState("");
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState("");

  const fetchWeather = async () => {
    if (!city) return;
    try {
      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      );
      const data = await res.json();
      if (data.cod !== 200) throw new Error(data.message);
      setWeatherData(data);
      setError("");
    } catch (err) {
      setError(err.message);
      setWeatherData(null);
    }
  };

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h1>🌤️ AI Weather & Clothing Suggestions</h1>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        style={{ padding: '10px', fontSize: '16px', width: '250px' }}
      />
      <button onClick={fetchWeather} style={{ padding: '10px 20px', marginLeft: '10px' }}>
        Get Forecast
      </button>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {weatherData && (
        <div style={{ marginTop: '20px', background: '#fff', padding: '20px', borderRadius: '8px', display: 'inline-block' }}>
          <h2>{weatherData.name}, {weatherData.sys.country}</h2>
          <p>{weatherData.weather[0].description}</p>
          <p><strong>{weatherData.main.temp}°C</strong></p>
          <p>👕 Suggestion: {getClothingSuggestion(weatherData.main.temp, weatherData.weather[0].main.toLowerCase())}</p>
        </div>
      )}
    </div>
  );
}
